from django.shortcuts import render
from django.http import JsonResponse
from django.views.decorators.http import require_GET
from .services.weather import OpenWeatherMapAdapter,MockWeatherService #import the adapter(s)
import requests

# Create your views here.

#Initilaise the weather service or mock weather service
API_KEY = "fcafcf20ade543d16a674c90297fe151"
if API_KEY:
    weather_service = OpenWeatherMapAdapter(api_key = API_KEY)
else:
    weather_service = MockWeatherService

#Initialise the weather adapter
#weather_service = OpenWeatherMapAdapter(api_key="fcafcf20ade543d16a674c90297fe151")

def index(request):
    """Render the frontend HTML page."""
    return render(request, "index.html")

# External API Keys (can be replaced with users API keys)
# WEATHER_API_KEY = "your_openweathermap_api_key"
# WEATHER_API_URL = "https://api.openweathermap.org/data/2.5/weather"

ROUTE_API_KEY = "AIzaSyBAkiKcCdQjImxwJjG9cUqHlt2rOZqMg5w"
ROUTE_API_URL = "https://maps.googleapis.com/maps/api/directions/json"

# Mock knowledge base for activity suggestions
ACTIVITY_KNOWLEDGE_BASE = {
    "Outdoor": [
        {"name": "Hiking", "description": "Enjoy a scenic hike in nature.", "location": "Manchester"},
        {"name": "Cycling", "description": "Explore the city on a bike.", "location": "Bristol"}
    ],
    "Indoor": [
        {"name": "Visit a Museum", "description": "Explore art and history.", "location": "Leeds"},
        {"name": "Watch a Movie", "description": "Relax with a good film.", "location": "Liverpool"}
    ]
}

# def get_weather(city):
#     """Fetch weather data for a given city using OpenWeatherMap API."""
#     params = {
#         "q": city,
#         "appid": WEATHER_API_KEY,
#         "units": "metric"
#     }
#     response = requests.get(WEATHER_API_URL, params=params)
#     if response.status_code == 200:
#         data = response.json() # return local information
#         return {
#             "temperature": data["main"]["temp"],
#             "conditions": data["weather"][0]["description"],
#             "precipitation": data.get("rain", {}).get("1h", 0),  # Precipitation in the last hour
#             "windSpeed": data["wind"]["speed"]
#         }
#     else:
#         return None

# Route planning function
def get_route(start, end):
    """Fetch route details using Google Maps Directions API."""
    params = {
        "origin": start,
        "destination": end,
        "key": ROUTE_API_KEY,
        "mode": "driving"  # Default mode is walking e.g. on the GPS (api)
    }
    print(f"Fetching route from {start} to {end}")  # Debugging Purposes
    response = requests.get(ROUTE_API_URL, params=params)
    if response.status_code == 200:
        data = response.json()
        if data["status"] == "OK":
            route = data["routes"][0]["legs"][0]
            return {
                "distance": route["distance"]["value"] / 1000,  # Convert meters to kilometers
                "duration": route["duration"]["value"] / 60,  # Convert seconds to minutes
                "steps": [step["html_instructions"] for step in route["steps"]]
            }
    print(f"Warning: Failed to fetch route from {start} to {end}")  # Debugging Purposes
    return None

def suggest_activities(weather):
    """Suggest activities based on weather conditions in degrees Celsius."""
    if weather["temperature"] > 15 and weather["precipitation"] < 1 and weather["windSpeed"] < 20:
        return ACTIVITY_KNOWLEDGE_BASE["Outdoor"]
    else:
        return ACTIVITY_KNOWLEDGE_BASE["Indoor"]

@require_GET
def suggest_activities_endpoint(request):
    """Endpoint to suggest activities based on city name."""
    city = request.GET.get("city")
    if not city:
        return JsonResponse({"error": "City parameter is required"}, status=400)

    # Fetch weather data using the adapter or  mock service
    try:
        weather = weather_service.get_weather(city)
    except Exception as e:
        return JsonResponse({"error": str(e)}, status=400) #Bad request
    except Exception as e:
        return JsonResponse({"error": str(e)}, status=500) #Internl Server error

    # Suggest activities
    activities = suggest_activities(weather)

    # Add route details to activities
    for activity in activities:
        route = get_route(city, activity["location"])
        if route:
            activity["route"] = route

    # Return response
    return JsonResponse({
        "weather": weather,
        "activities": activities
    })