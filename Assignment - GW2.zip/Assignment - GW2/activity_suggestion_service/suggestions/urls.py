from django.urls import path
from . import views

urlpatterns = [
    path("", views.index, name = "index"),
    path("api/suggest-activities/", views.suggest_activities_endpoint, name="suggest-activities"),
]