from abc import ABC, abstractmethod
import requests

class WeatherService(ABC):
    @abstractmethod
    def get_weather(self, city: str) -> dict:
        """
        Fetch weather data for a given city.
        Returns a dictionary with temperature, conditions, precipitation, and wind speed.
        """
        pass

# Adapter for the OpenWeatherMap API
class OpenWeatherMapAdapter(WeatherService):
    def __init__(self, api_key: str):
        if not api_key:
            raise ValueError("API Key Required")
        self.api_key = api_key
        self.base_url = "https://api.openweathermap.org/data/2.5/weather"

    def get_weather(self, city: str) -> dict:
        """Fetch weather data from OpenWeatherMap and adapt it to the required format."""
        params = {
            "q": city,
            "appid": self.api_key,
            "units": "metric"
        }
        response = requests.get(self.base_url, params=params)
        if response.status_code == 200:
            data = response.json()
            return {
                "temperature": data["main"]["temp"],
                "conditions": data["weather"][0]["description"],
                "precipitation": data.get("rain", {}).get("1h", 0),
                "windSpeed": data["wind"]["speed"]
            }
        else:
            raise Exception(f"Failed to fetch weather data: {response.status_code} - {response.text}")

# Mock Test
class MockWeatherService(WeatherService):
    def get_weather(self, city: str) -> dict:
        """Mock Weather data for testing purposes."""
        return {
            # mock values
            "temperature": 20.0,
            "conditions": "Sunny",
            "precipitation": 0,
            "windSpeed": 5.0
        }